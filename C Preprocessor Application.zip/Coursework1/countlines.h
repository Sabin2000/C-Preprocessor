#pragma once

void countLines(FILE *fileName);