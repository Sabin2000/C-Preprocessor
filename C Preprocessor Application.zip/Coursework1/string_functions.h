void chomp(char *string);
int my_strlen(char *string);
int my_strcmp(char *string1, char *string2);
