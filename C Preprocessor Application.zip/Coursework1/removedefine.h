#pragma once

void removeStringDefine(FILE *stringFile);
void removeMathDefine(FILE *mathFile);