#pragma once

void removeComments(FILE *fileName, FILE *outputFile);