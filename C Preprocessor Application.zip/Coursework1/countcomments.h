#pragma once

void countComments(FILE *fileName);