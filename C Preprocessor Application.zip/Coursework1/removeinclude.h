#pragma once

void removeInclude(FILE *fileName, FILE *outputFile);