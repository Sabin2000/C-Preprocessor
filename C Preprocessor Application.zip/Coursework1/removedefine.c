#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define STRINGSIZE 512
#define MATHSIZE 512

