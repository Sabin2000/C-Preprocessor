int add(int a, int b);
int subtract_from_const(int n);
int multiply_by_const(int n);
double divide_by_const(int n);
double average(int size, int *array);
double area_of_circle(double radius);
int light_speed();